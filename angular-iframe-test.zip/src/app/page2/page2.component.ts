import {Component} from "@angular/core";

@Component({
  selector: 'page2',
  templateUrl: 'page2.component.html'
})
export class Page2Component {}
